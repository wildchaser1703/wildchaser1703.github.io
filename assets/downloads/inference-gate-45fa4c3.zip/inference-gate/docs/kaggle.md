# Free Kaggle GPU experiment

The supplied `notebooks/kaggle.ipynb` automates the steps below. Import it into
Kaggle and attach `inference-gate-source.zip` as a private input.
The setup cell handles both intact ZIPs and inputs automatically extracted by
Kaggle. Run setup and installation first. Restart the Python kernel if torch was
replaced, then run the experiment cell and finally the evidence download cell.
If an experiment fails, preserve its error output and `engine.log`; do not treat
a partial evidence archive as a completed experiment.

1. Create a private Kaggle notebook. Select a free T4 GPU and enable
   Internet for the public package/model downloads. No tokens or secrets needed.
   P100 is not supported by this vLLM path; the script checks compute capability.
2. Upload a ZIP of this repository as a private notebook input and unzip it into
   `/kaggle/working/inference-gate`. If a public source repository is available,
   cloning it is also sufficient. Do not upload `.venv` or model caches.
3. Run these cells from the source directory:

```python
%cd /kaggle/working/inference-gate
%pip install -e . "vllm>=0.8,<0.12"
```

If installation changes torch, restart the notebook session before continuing.
Use a fresh notebook to avoid mixing preinstalled ML dependencies. vLLM releases
and CUDA wheels vary: this compatibility path is pending an actual Kaggle run.

```python
!python -m gate.profile --kv-mib 128
!python scripts/kaggle_run.py
```

The script uses one GPU, a pinned 135M model, FP16, eager execution, context 2048,
and a 50% engine memory setting. It runs three load levels, both policies, and
three repetitions. Servers bind only to localhost. The conservative 2048-token
gateway budget is an experimental control, not the entire available VRAM.

Download `/kaggle/working/inference-gate-results` before ending the session. It
contains GPU identity, installed package versions, engine settings and logs,
every raw request, and trial summaries. Compare identical workload hashes across
policies and report errors as well as successful latency. If results do not show
an advantage, report that: this project studies the tradeoff rather than assuming
the token policy always wins.

No paid GPU fallback, API key, public tunnel, or hosted endpoint is necessary.
